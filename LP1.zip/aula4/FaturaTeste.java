package aula4;

//Alunos: Victor Emannuel e Welder

public class FaturaTeste {

    public static void main(String[] args) {
        Fatura fatura1 = new Fatura("f1", null, 5, 10.5);
        System.out.println(fatura1.getTotalFatura());
    }
}