package aula6;

//Alunos: Victor Emannuel e Welder

public class DataTeste {
    public static void main(String[] args) {
        Data d1 = new Data(24, 02, 2023);

        d1.displayData(d1.getDia(), d1.getMes(), d1.getAno());
    }
}
